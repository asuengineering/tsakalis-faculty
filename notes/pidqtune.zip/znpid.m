function C=znpid(R,L,n)
% C=znpid(R,L,n)
% Ziegler-Nichols PID Tuning
%R=slope L=delay, or R=Ku=ultimate gain, L=Pu=ultimate period

Kp=0;Ki=0;Kd=0;
if n>0
    if n==1
        Kp=1/R/L;
    elseif n==2
        Kp=0.9/R/L;Ki=0.27/R/L/L;
    else
        Kp=1.2/R/L;Ki=0.6/R/L/L;Kd=0.5/R;
    end
else
    Ku=R;Pu=L;
    if n==-1
        Kp=0.5*Ku;
    elseif n==-2
        Kp=.45*Ku;Ki=0.54*Ku/Pu;
    else
        Kp=.6*Ku;Ki=1.2*Ku/Pu;Kd=0.075*Ku*Pu;
    end
end
C=Kp+Ki*tf(1,[1 0])+Kd*tf([1 0],[1]);