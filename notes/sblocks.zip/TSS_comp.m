function [N,TSS,Tc0,TSSmax,TSSmin]=tss_comp(Fl,T_a0,q,tol);
%function [N,TSS,Tc0,TSSmax,TSSmin]=tss_comp(Fl,T_a0,q,tol);
% Steady-state Solution of the tube heating problem
% INPUTS:
%   Fl = air flow (lit/min), T_a0 = air temperature at the inlet
%   q = fraction of heating power (qmax = 10kW)
%   tol = solution tolerance (optional)
%   (The rest of the problem parameters can be adjusted by editing the file)
% OUTPUTS:
%   N = length (0-L), TSS = SS solution (T_wall, dT_wall/dx, T_air]
%   Tc0 = Initial state (x=0) of the solution
%   TSSmax, TSSmin = upper-lower bounds for the solution (useful in
%                    forced terminations)
% DISPLAYS:
%   T_wall(0) interval length, max-error, min-error (end-point heat flux)



%KST 8/15/01

if nargin<4;tol=1;end

% Model Parameters
L=1;F=Fl*1e-3/60;T_amb=25;qmax=10000;
n=1000;
cp=1078;cpa=1134;rhoa=0.5;hs=5;ha=30;rhos=2500;k=2;
ra=.1;d=.01;vt=pi*L*((ra+d)*(ra+d)-ra*ra);m=vt*rhos;
As=2*pi*(ra+.1)*L;V=pi*ra*ra*L;Aa=2*pi*ra*L;
A_d=pi*((ra+d)*(ra+d)-ra*ra);A_rat=1;Li=L/n;


HS=hs*As/m/cp; HA=ha*Aa/m/cp;
a_=k/rhos/cp;
v=F*L/V;HAA=ha*Aa/rhoa/V/cpa;

% Overall linear System Tc' = Ac*Tc + Bc
%                       Tc = [T, T', Ta]
Ac = [0 1 0; (HS+HA)/a_ 0 -HA/a_;HAA/v 0 -HAA/v];eig(Ac);
Bc = [0;(-q*qmax/m/cp-HS*T_amb)/a_;0];
Cc=[1 0 0;0 1 0;0 0 1];Dc=[0;0;0];
Tbound=-Cc*inv(Ac)*Bc

% Iterate steady-state profiles (too sensitive for direct solution)
N=[0:L/n:L]';Tmin=T_amb;Tmax=Tbound(1);
err=inf;

while err>tol
T0=[Tmin:(Tmax-Tmin)/10:Tmax]';NN=length(T0);
x=zeros(NN,1);
for i=1:NN
    T0i=T0(i);
    Tc0=[T0i;hs/k*(T0i-T_amb);T_a0];
    TSS = lsim(Ac,Bc,Cc,Dc,0*N+1,N,Tc0);
    x(i)=-k*TSS(length(N),2)-hs*(TSS(length(N),1)-T_amb);
end
s1=sign(x(1));s2=sign(x(NN));
ind1=max(find(sign(x)==s1));ind2=min(find(sign(x)==s2));
Tmin=T0(ind1);Tmax=T0(ind2);
[Tmax-Tmin x(ind1),x(ind2)]
T0e=(Tmin+Tmax)/2;
    Tc0=[T0e;hs/k*(T0e-T_amb);T_a0];
    TSS = lsim(Ac,Bc,Cc,Dc,0*N+1,N,Tc0);
    erre=abs(-k*TSS(length(N),2)-hs*(TSS(length(N),1)-T_amb));
    err=max(abs(x(ind1)),abs(x(ind2)));
    if Tmax-Tmin<1e-12;if err >tol;disp('FORCED TERMINATION');err=0;end;end

end
    Tc01=[Tmax;hs/k*(Tmax-T_amb);T_a0];
    TSSmax = lsim(Ac,Bc,Cc,Dc,0*N+1,N,Tc01);
    Tc02=[Tmin;hs/k*(Tmin-T_amb);T_a0];
    TSSmin = lsim(Ac,Bc,Cc,Dc,0*N+1,N,Tc02);

plot(N,TSS(:,[1 3]))
title('Steady-state profile of Wall and Air temperatures')