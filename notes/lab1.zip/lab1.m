% Script for Lab 1, Execute by typing its name in the Matlab command window.
% Written in Matlab V6 (Release 12)
% KST, 8/24/01

disp('*** Experiment 1 ***')
eval('help tf') % for use inside functions 
help tfdata     % or simply...

disp('*** Experiment 2 ***')
t=[-10:.1:10]';       % create a time vector (column convention)
y=t+0.01*t.^3+cos(t); % Eval the function
w=[t 0*t+1];          % form the regressor vector
ab=w\y                % Compute the LS solution; same as inv(w'*w)*w'*y
yh=w*ab;              % Eval the straight-line approximation; same as ab(1)*t+ab(2)
subplot(121)          % Multi-plot figures
plot(t,y,t,yh)        % plot multiple lines
ylabel('y(t),  y_{LS} (t)')    % add axis labels 
xlabel('t, in default time units (DTU)')
title('LS straight line approximation')
subplot(122)          % next plot
plot(t,y-yh)
ylabel('LS error')
xlabel('t (DTU)')
title('Fitting error')
disp(' When done hit <space> to continue')
pause                 % pause to examine the figure; resume with <space> 

disp('*** Experiment 3 ***')
disp('On the figure window click <Edit/Copy Options> and select Bitmap format...')
disp('  then click <Edit/Copy Figure>, go to your Word document and <paste>...')
disp('  In the document, right click on the figure, select <format.../size>,...')
disp('  and resize the figure as necessary. Keep the <Lock aspect ratio> box checked.')
disp(' ')
disp(' When done hit <space> to continue')
pause

disp('*** Experiment 4 ***')
clf                   % clear figure/reset 
G1=tf(1,[5 1]);       % create a transfer function object
G2=tf(1,[1 .3 1]);
disp('Bode plot 1')
bode(G1);pause        % Generate the Bode plot (auto-axis, generic labels)
disp('Bode plot 2')
bode(G2);pause
disp('Step 1')
step(G1);pause        % Generate the unit step response
disp('Step 2')
step(G2);pause

disp('*** Experiment 5 ***')
simulink                % Start Simulink ...
disp('*** Work on the Simulink window... ***')
disp('*** Experiment 6 ***')
disp('G_2(s)G_1(s)')
G21=series(G1,G2)       % Create the cascade connection
disp('Step of G_2(s)G_1(s)')
step(G21);pause
disp('another computation of the same thing')
step(G2*G1,'r'); pause  % Also works like this; *,/,+,- are overlayed operations
                        % with their systems-interpretation when the objects are systems.
                        % The 'r' is to change the display color
disp('The unity-feedback loop of G_2(s)G_1(s)')
Gf=feedback(G21,1)      % Now the feedback
step(Gf);pause  
disp('another computation of the same thing')
step(G2*G1/(1+G2*G1),'m');pause   % just as well...
                                  % but not a good way: it fails for RHP modes
disp('*** Experiment 7 ***')
G21ss=ss(G21);
Gfss=ss(Gf);            % Much easier than the old ss2tf or tf2ss
                        % You could also define a system in state-space by G=ss(A,B,C,D)
disp('A and C -matrices  for the feedback system')
Gfss.a                  % display the A-matrix of the system Gfss
Gfss.c                  % etc
pause

disp('*** Experiment 8 ***')
% Now we need the numerators/denominators and A-matrices of G21 and Gf
[num21,den21] = tfdata(G21,'v');   % 'v' to get the result in vectors
[numf,denf] = tfdata(Gf,'v'); 
a21 = G21ss.a;
af = Gfss.a;
disp('poles of G21')
roots(den21), pause      % you can use , for displaying results in in-line commands
disp('eigenvalues of A21')
eig(a21), pause
disp('partial fraction expansion of G_2(s)G_1(s)')
[r,p,k]=residue(num21,den21);
disp('residues'),r,pause
disp('poles'),p,pause
disp('feed-through (if any)'),k,pause


disp('*** Experiments 9-10 ***')
disp('... on the Simulink window... ')
disp('END OF DEMO! You should know enough by now...')



                  