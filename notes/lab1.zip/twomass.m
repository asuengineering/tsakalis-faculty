% 2-mass system problem (friction/spring/damping)

% Define the problem parameters
m1=1;b1=.1;  
k=10;b=.1;
m2=.5;b2=.1;
w=logspace(-3,2,300);

% Define the controllers (tuned for the rigid approx.) 
% 
PID1 =[  6.1954e-001  1.2065e-001  1.4504e-002
  1.0000e+000  1.0000e+000            0
  1.0615e-001  1.4504e-002  5.1340e-001];
PID2 =[  1.6442e+000  6.3475e-001  1.9407e-001
  4.0000e-001  1.0000e+000            0
  5.5712e-001  1.9407e-001  1.4213e+000];
PID3 =[  3.4173e+000  2.4201e+000  1.4943e+000
  2.0000e-001  1.0000e+000            0
  2.1212e+000  1.4943e+000  2.9931e+000];
  
% Set up system state space
A=[0 1 0 0;[-k -b-b1 k b]/m1;0 0 0 1;[k b -k -b-b2]/m2];
B=[0; 1/m1; 0; 0]; C1=[1 0 0 0]; C2=[0 0 1 0]; D=0;
% and compute transfer functions to mass 1,2 displacements
gf1ss=ss(A,B,C1,D); gf2ss=ss(A,B,C2,D);
gf1=tf(gf1ss);gf2=tf(gf2ss);
% The rigid body approximation is the same for both
gr=tf(1,[m1+m2 b1+b2 0]);
% Compare the frequency and impulse responses of the two models and
%   the rigid body approximation
bode(gr,gf1,gf2)
disp('Freq. response of the two models and the rigid body approximation');pause
impulse(gr,gf1,gf2)
disp('Impulse response of the two models and the rigid body approximation');pause

% Generate plots of the inverse multiplicative for each case
% The magnitude is the upper bound for the complementary sensitivity
bode(gr/(gf1-gr),gr/(gf2-gr),w);disp('Inverse Multiplicative Uncertainty: Complementary sensitivity (T) constraints');pause

% Evaluate the designs for the control of the first or the second mass displacement

% 1st controller, tuned with the rigid model for a BW ~0.6 
gpid=tf(PID1(1,:),PID1(2,:));
bode(gr/(gf1-gr),gr/(gf2-gr),feedback(gpid*gr,1),w);
disp('Low BW controller, constraints and nominal T (plenty of margin)');pause
step(feedback(gpid*gr,1),feedback(gpid*gf1,1),feedback(gpid*gf2,1));
disp('Low BW controller, step responses (very predictable)');pause

% 2nd controller, tuned with the rigid model for a BW ~1.7 
gpid=tf(PID2(1,:),PID2(2,:));
bode(gr/(gf1-gr),gr/(gf2-gr),feedback(gpid*gr,1),w);
disp('Medium BW controller, constraints and nominal T (virtually no margin)');pause
step(feedback(gpid*gr,1),feedback(gpid*gf1,1),feedback(gpid*gf2,1));
disp('Medium BW controller, step responses (excitation of the flexible modes)');pause

% 1st controller, tuned with the rigid model for a BW ~3.5
gpid=tf(PID3(1,:),PID3(2,:));
bode(gr/(gf1-gr),gr/(gf2-gr),feedback(gpid*gr,1),w);
disp('Hi BW controller, constraints and nominal T (constraints are violated)');pause
t=[0:.01:5]';
step(feedback(gpid*gr,1),feedback(gpid*gf1,1),feedback(gpid*gf2,1),t);
disp('Hi BW controller, step responses (instability of the 2nd mass loop)');pause



