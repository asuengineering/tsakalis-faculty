w=logspace(-4,2,200)';
G=zeros(200,length(ii));
for j=1:length(ii)
dnum=Q(ii(j),1:N);
dden=[1 -Q(ii(j),N+1:2*N)];
Pd=tf(dnum,dden,.2);
Pc=d2c(Pd);
m=bode(Pc,w);
G(:,j)=m(:);
end
