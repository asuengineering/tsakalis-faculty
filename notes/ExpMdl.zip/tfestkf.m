[tem,mm]=size(ZKF);

w=logspace(-4,4,300)';GKF=zeros(300,length(ii));
GLS=GKF;G498=GKF;

for j=1:length(ii)
   q1=ZKF(ii(j),1:f_ord); q2=ZKF(ii(j),f_ord+1:2*f_ord); q3=ZKF(ii(j),mm-1*ct)*thru;
   Pd=ss(eye(size(f))+f'+q1'*q,q2'+q1'*q3,q,q3,Tsa); Pc=d2c(Pd); m=bode(Pc,w); GKF(:,j)=m(:);
end

for j=1:length(ii)
   Pd1=tf(ZLS(ii(j),1:N),[1 -ZLS(ii(j),N+1:2*N)],Tsa);
   Pc1=d2c(Pd1); m=bode(Pc1,w); GLS(:,j)=m(:);
   Pd1=tf(Z498(ii(j),1:N),[1 -Z498(ii(j),N+1:2*N)],Tsa);
   Pc1=d2c(Pd1); m=bode(Pc1,w); G498(:,j)=m(:);
end
