function pt = exp5apt(flag)

if nargin == 0
  pt = [];
	    pt(1).blockname = 'Pulse Generator';
	    pt(1).paramname = 'Amplitude';
	    pt(1).class     = 'rt_SCALAR';
	    pt(1).nrows     = 1;
	    pt(1).ncols     = 1;
	    pt(1).subsource = 'SS_DOUBLE';

	    pt(2).blockname = 'Pulse Generator';
	    pt(2).paramname = 'Period';
	    pt(2).class     = 'rt_SCALAR';
	    pt(2).nrows     = 1;
	    pt(2).ncols     = 1;
	    pt(2).subsource = 'SS_DOUBLE';

	    pt(3).blockname = 'Pulse Generator';
	    pt(3).paramname = 'PulseWidth';
	    pt(3).class     = 'rt_SCALAR';
	    pt(3).nrows     = 1;
	    pt(3).ncols     = 1;
	    pt(3).subsource = 'SS_DOUBLE';

	    pt(4).blockname = 'Gain';
	    pt(4).paramname = 'Gain';
	    pt(4).class     = 'rt_SCALAR';
	    pt(4).nrows     = 1;
	    pt(4).ncols     = 1;
	    pt(4).subsource = 'SS_DOUBLE';

	    pt(5).blockname = 'Gain1';
	    pt(5).paramname = 'Gain';
	    pt(5).class     = 'rt_SCALAR';
	    pt(5).nrows     = 1;
	    pt(5).ncols     = 1;
	    pt(5).subsource = 'SS_DOUBLE';

	    pt(6).blockname = 'MM';
	    pt(6).paramname = 'P1';
	    pt(6).class     = 'rt_SCALAR';
	    pt(6).nrows     = 1;
	    pt(6).ncols     = 1;
	    pt(6).subsource = 'SS_DOUBLE';

	    pt(7).blockname = 'MM';
	    pt(7).paramname = 'P2';
	    pt(7).class     = 'rt_SCALAR';
	    pt(7).nrows     = 1;
	    pt(7).ncols     = 1;
	    pt(7).subsource = 'SS_DOUBLE';

	    pt(8).blockname = 'MM';
	    pt(8).paramname = 'P3';
	    pt(8).class     = 'rt_SCALAR';
	    pt(8).nrows     = 1;
	    pt(8).ncols     = 1;
	    pt(8).subsource = 'SS_DOUBLE';

	    pt(9).blockname = 'MM';
	    pt(9).paramname = 'P4';
	    pt(9).class     = 'rt_SCALAR';
	    pt(9).nrows     = 1;
	    pt(9).ncols     = 1;
	    pt(9).subsource = 'SS_DOUBLE';

	    pt(10).blockname = 'MM';
	    pt(10).paramname = 'P5';
	    pt(10).class     = 'rt_SCALAR';
	    pt(10).nrows     = 1;
	    pt(10).ncols     = 1;
	    pt(10).subsource = 'SS_DOUBLE';

	    pt(11).blockname = 'MM';
	    pt(11).paramname = 'P6';
	    pt(11).class     = 'rt_SCALAR';
	    pt(11).nrows     = 1;
	    pt(11).ncols     = 1;
	    pt(11).subsource = 'SS_DOUBLE';

	    pt(12).blockname = 'MM 1';
	    pt(12).paramname = 'P1';
	    pt(12).class     = 'rt_SCALAR';
	    pt(12).nrows     = 1;
	    pt(12).ncols     = 1;
	    pt(12).subsource = 'SS_DOUBLE';

	    pt(13).blockname = 'MM 1';
	    pt(13).paramname = 'P2';
	    pt(13).class     = 'rt_SCALAR';
	    pt(13).nrows     = 1;
	    pt(13).ncols     = 1;
	    pt(13).subsource = 'SS_DOUBLE';

	    pt(14).blockname = 'MM 1';
	    pt(14).paramname = 'P3';
	    pt(14).class     = 'rt_SCALAR';
	    pt(14).nrows     = 1;
	    pt(14).ncols     = 1;
	    pt(14).subsource = 'SS_DOUBLE';

	    pt(15).blockname = 'MM 1';
	    pt(15).paramname = 'P4';
	    pt(15).class     = 'rt_SCALAR';
	    pt(15).nrows     = 1;
	    pt(15).ncols     = 1;
	    pt(15).subsource = 'SS_DOUBLE';

	    pt(16).blockname = 'MM 1';
	    pt(16).paramname = 'P5';
	    pt(16).class     = 'rt_SCALAR';
	    pt(16).nrows     = 1;
	    pt(16).ncols     = 1;
	    pt(16).subsource = 'SS_DOUBLE';

	    pt(17).blockname = 'MM 1';
	    pt(17).paramname = 'P6';
	    pt(17).class     = 'rt_SCALAR';
	    pt(17).nrows     = 1;
	    pt(17).ncols     = 1;
	    pt(17).subsource = 'SS_DOUBLE';

	    pt(18).blockname = 'Step1';
	    pt(18).paramname = 'Time';
	    pt(18).class     = 'rt_SCALAR';
	    pt(18).nrows     = 1;
	    pt(18).ncols     = 1;
	    pt(18).subsource = 'SS_DOUBLE';

	    pt(19).blockname = 'Step1';
	    pt(19).paramname = 'Before';
	    pt(19).class     = 'rt_SCALAR';
	    pt(19).nrows     = 1;
	    pt(19).ncols     = 1;
	    pt(19).subsource = 'SS_DOUBLE';

	    pt(20).blockname = 'Step1';
	    pt(20).paramname = 'After';
	    pt(20).class     = 'rt_SCALAR';
	    pt(20).nrows     = 1;
	    pt(20).ncols     = 1;
	    pt(20).subsource = 'SS_DOUBLE';

	    pt(21).blockname = 'Step2';
	    pt(21).paramname = 'Time';
	    pt(21).class     = 'rt_SCALAR';
	    pt(21).nrows     = 1;
	    pt(21).ncols     = 1;
	    pt(21).subsource = 'SS_DOUBLE';

	    pt(22).blockname = 'Step2';
	    pt(22).paramname = 'Before';
	    pt(22).class     = 'rt_SCALAR';
	    pt(22).nrows     = 1;
	    pt(22).ncols     = 1;
	    pt(22).subsource = 'SS_DOUBLE';

	    pt(23).blockname = 'Step2';
	    pt(23).paramname = 'After';
	    pt(23).class     = 'rt_SCALAR';
	    pt(23).nrows     = 1;
	    pt(23).ncols     = 1;
	    pt(23).subsource = 'SS_DOUBLE';

	    pt(24).blockname = 'CONTROL/Unit Delay';
	    pt(24).paramname = 'X0';
	    pt(24).class     = 'rt_SCALAR';
	    pt(24).nrows     = 1;
	    pt(24).ncols     = 1;
	    pt(24).subsource = 'SS_DOUBLE';

	    pt(25).blockname = 'Send /S-Function';
	    pt(25).paramname = 'P1';
	    pt(25).class     = 'rt_SCALAR';
	    pt(25).nrows     = 1;
	    pt(25).ncols     = 1;
	    pt(25).subsource = 'SS_DOUBLE';

	    pt(26).blockname = 'Send /S-Function';
	    pt(26).paramname = 'P2';
	    pt(26).class     = 'rt_VECTOR';
	    pt(26).nrows     = 1;
	    pt(26).ncols     = 12;
	    pt(26).subsource = 'SS_DOUBLE';

	    pt(27).blockname = 'Send /S-Function';
	    pt(27).paramname = 'P3';
	    pt(27).class     = 'rt_SCALAR';
	    pt(27).nrows     = 1;
	    pt(27).ncols     = 1;
	    pt(27).subsource = 'SS_DOUBLE';

	    pt(28).blockname = 'Send /S-Function';
	    pt(28).paramname = 'P4';
	    pt(28).class     = 'rt_SCALAR';
	    pt(28).nrows     = 1;
	    pt(28).ncols     = 1;
	    pt(28).subsource = 'SS_DOUBLE';

	    pt(29).blockname = 'Setup /S-Function';
	    pt(29).paramname = 'P1';
	    pt(29).class     = 'rt_SCALAR';
	    pt(29).nrows     = 1;
	    pt(29).ncols     = 1;
	    pt(29).subsource = 'SS_DOUBLE';

	    pt(30).blockname = 'Setup /S-Function';
	    pt(30).paramname = 'P2';
	    pt(30).class     = 'rt_SCALAR';
	    pt(30).nrows     = 1;
	    pt(30).ncols     = 1;
	    pt(30).subsource = 'SS_DOUBLE';

	    pt(31).blockname = 'Setup /S-Function';
	    pt(31).paramname = 'P3';
	    pt(31).class     = 'rt_SCALAR';
	    pt(31).nrows     = 1;
	    pt(31).ncols     = 1;
	    pt(31).subsource = 'SS_DOUBLE';

	    pt(32).blockname = 'Setup /S-Function';
	    pt(32).paramname = 'P4';
	    pt(32).class     = 'rt_SCALAR';
	    pt(32).nrows     = 1;
	    pt(32).ncols     = 1;
	    pt(32).subsource = 'SS_DOUBLE';

	    pt(33).blockname = 'Setup /S-Function';
	    pt(33).paramname = 'P5';
	    pt(33).class     = 'rt_SCALAR';
	    pt(33).nrows     = 1;
	    pt(33).ncols     = 1;
	    pt(33).subsource = 'SS_DOUBLE';

	    pt(34).blockname = 'Setup /S-Function';
	    pt(34).paramname = 'P6';
	    pt(34).class     = 'rt_SCALAR';
	    pt(34).nrows     = 1;
	    pt(34).ncols     = 1;
	    pt(34).subsource = 'SS_DOUBLE';

	    pt(35).blockname = 'Setup /S-Function';
	    pt(35).paramname = 'P7';
	    pt(35).class     = 'rt_SCALAR';
	    pt(35).nrows     = 1;
	    pt(35).ncols     = 1;
	    pt(35).subsource = 'SS_DOUBLE';

	    pt(36).blockname = 'Setup /S-Function';
	    pt(36).paramname = 'P8';
	    pt(36).class     = 'rt_SCALAR';
	    pt(36).nrows     = 1;
	    pt(36).ncols     = 1;
	    pt(36).subsource = 'SS_DOUBLE';

	    pt(37).blockname = 'Setup /S-Function';
	    pt(37).paramname = 'P9';
	    pt(37).class     = 'rt_SCALAR';
	    pt(37).nrows     = 1;
	    pt(37).ncols     = 1;
	    pt(37).subsource = 'SS_DOUBLE';

	    pt(38).blockname = 'CONTROL/AW-PID 1/Constant';
	    pt(38).paramname = 'Value';
	    pt(38).class     = 'rt_SCALAR';
	    pt(38).nrows     = 1;
	    pt(38).ncols     = 1;
	    pt(38).subsource = 'SS_DOUBLE';

	    pt(39).blockname = 'CONTROL/AW-PID 1/Proportional';
	    pt(39).paramname = 'Gain';
	    pt(39).class     = 'rt_SCALAR';
	    pt(39).nrows     = 1;
	    pt(39).ncols     = 1;
	    pt(39).subsource = 'SS_DOUBLE';

	    pt(40).blockname = 'CONTROL/AW-PID 1/Proportional3';
	    pt(40).paramname = 'Gain';
	    pt(40).class     = 'rt_SCALAR';
	    pt(40).nrows     = 1;
	    pt(40).ncols     = 1;
	    pt(40).subsource = 'SS_DOUBLE';

	    pt(41).blockname = 'CONTROL/AW-PID 1/gain';
	    pt(41).paramname = 'Gain';
	    pt(41).class     = 'rt_SCALAR';
	    pt(41).nrows     = 1;
	    pt(41).ncols     = 1;
	    pt(41).subsource = 'SS_DOUBLE';

	    pt(42).blockname = 'CONTROL/AW-PID 1/Saturation';
	    pt(42).paramname = 'UpperLimit';
	    pt(42).class     = 'rt_SCALAR';
	    pt(42).nrows     = 1;
	    pt(42).ncols     = 1;
	    pt(42).subsource = 'SS_DOUBLE';

	    pt(43).blockname = 'CONTROL/AW-PID 1/Saturation';
	    pt(43).paramname = 'LowerLimit';
	    pt(43).class     = 'rt_SCALAR';
	    pt(43).nrows     = 1;
	    pt(43).ncols     = 1;
	    pt(43).subsource = 'SS_DOUBLE';

	    pt(44).blockname = 'CONTROL/meas>0/Unit Delay3';
	    pt(44).paramname = 'X0';
	    pt(44).class     = 'rt_SCALAR';
	    pt(44).nrows     = 1;
	    pt(44).ncols     = 1;
	    pt(44).subsource = 'SS_DOUBLE';

	    pt(45).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/exp.weight';
	    pt(45).paramname = 'Value';
	    pt(45).class     = 'rt_SCALAR';
	    pt(45).nrows     = 1;
	    pt(45).ncols     = 1;
	    pt(45).subsource = 'SS_DOUBLE';

	    pt(46).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/init.cov';
	    pt(46).paramname = 'Value';
	    pt(46).class     = 'rt_MATRIX_COL_MAJOR';
	    pt(46).nrows     = 2;
	    pt(46).ncols     = 2;
	    pt(46).subsource = 'SS_DOUBLE';

	    pt(47).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/init.par';
	    pt(47).paramname = 'Value';
	    pt(47).class     = 'rt_VECTOR';
	    pt(47).nrows     = 2;
	    pt(47).ncols     = 1;
	    pt(47).subsource = 'SS_DOUBLE';

	    pt(48).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/Switch';
	    pt(48).paramname = 'Threshold';
	    pt(48).class     = 'rt_SCALAR';
	    pt(48).nrows     = 1;
	    pt(48).ncols     = 1;
	    pt(48).subsource = 'SS_DOUBLE';

	    pt(49).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/Switch1';
	    pt(49).paramname = 'Threshold';
	    pt(49).class     = 'rt_SCALAR';
	    pt(49).nrows     = 1;
	    pt(49).ncols     = 1;
	    pt(49).subsource = 'SS_DOUBLE';

	    pt(50).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/Unit Delay';
	    pt(50).paramname = 'X0';
	    pt(50).class     = 'rt_SCALAR';
	    pt(50).nrows     = 1;
	    pt(50).ncols     = 1;
	    pt(50).subsource = 'SS_DOUBLE';

	    pt(51).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/Unit Delay1';
	    pt(51).paramname = 'X0';
	    pt(51).class     = 'rt_SCALAR';
	    pt(51).nrows     = 1;
	    pt(51).ncols     = 1;
	    pt(51).subsource = 'SS_DOUBLE';

	    pt(52).blockname = 'CONTROL/AW-PID 1/integrator2/Constant';
	    pt(52).paramname = 'Value';
	    pt(52).class     = 'rt_SCALAR';
	    pt(52).nrows     = 1;
	    pt(52).ncols     = 1;
	    pt(52).subsource = 'SS_DOUBLE';

	    pt(53).blockname = 'CONTROL/AW-PID 1/integrator2/Constant3';
	    pt(53).paramname = 'Value';
	    pt(53).class     = 'rt_SCALAR';
	    pt(53).nrows     = 1;
	    pt(53).ncols     = 1;
	    pt(53).subsource = 'SS_DOUBLE';

	    pt(54).blockname = 'CONTROL/AW-PID 1/integrator2/Switch';
	    pt(54).paramname = 'Threshold';
	    pt(54).class     = 'rt_SCALAR';
	    pt(54).nrows     = 1;
	    pt(54).ncols     = 1;
	    pt(54).subsource = 'SS_DOUBLE';

	    pt(55).blockname = 'CONTROL/AW-PID 1/integrator2/Switch2';
	    pt(55).paramname = 'Threshold';
	    pt(55).class     = 'rt_SCALAR';
	    pt(55).nrows     = 1;
	    pt(55).ncols     = 1;
	    pt(55).subsource = 'SS_DOUBLE';

	    pt(56).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Gain';
	    pt(56).paramname = 'Gain';
	    pt(56).class     = 'rt_SCALAR';
	    pt(56).nrows     = 1;
	    pt(56).ncols     = 1;
	    pt(56).subsource = 'SS_DOUBLE';

	    pt(57).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Gain1';
	    pt(57).paramname = 'Gain';
	    pt(57).class     = 'rt_SCALAR';
	    pt(57).nrows     = 1;
	    pt(57).ncols     = 1;
	    pt(57).subsource = 'SS_DOUBLE';

	    pt(58).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Tapped Delay';
	    pt(58).paramname = 'InitialCondition';
	    pt(58).class     = 'rt_SCALAR';
	    pt(58).nrows     = 1;
	    pt(58).ncols     = 1;
	    pt(58).subsource = 'SS_DOUBLE';

	    pt(59).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Tapped Delay1';
	    pt(59).paramname = 'InitialCondition';
	    pt(59).class     = 'rt_SCALAR';
	    pt(59).nrows     = 1;
	    pt(59).ncols     = 1;
	    pt(59).subsource = 'SS_DOUBLE';

	    pt(60).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Uniform Random Number';
	    pt(60).paramname = 'Minimum';
	    pt(60).class     = 'rt_SCALAR';
	    pt(60).nrows     = 1;
	    pt(60).ncols     = 1;
	    pt(60).subsource = 'SS_DOUBLE';

	    pt(61).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Uniform Random Number';
	    pt(61).paramname = 'Maximum';
	    pt(61).class     = 'rt_SCALAR';
	    pt(61).nrows     = 1;
	    pt(61).ncols     = 1;
	    pt(61).subsource = 'SS_DOUBLE';

	    pt(62).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Uniform Random Number1';
	    pt(62).paramname = 'Minimum';
	    pt(62).class     = 'rt_SCALAR';
	    pt(62).nrows     = 1;
	    pt(62).ncols     = 1;
	    pt(62).subsource = 'SS_DOUBLE';

	    pt(63).blockname = 'ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Uniform Random Number1';
	    pt(63).paramname = 'Maximum';
	    pt(63).class     = 'rt_SCALAR';
	    pt(63).nrows     = 1;
	    pt(63).ncols     = 1;
	    pt(63).subsource = 'SS_DOUBLE';

else
  pt = 63;
end
