function xp=aar_com1(U,s_2);
% Experiment 3 communication function
% Inputs: Control vector, Serial object
% Outputs: Output vector (transmission, init flags)
% KST 8/04

t0=clock;
data_points=3;
g3='%8f,%8f,%8f';                                % R/W format
g6='%8f,%8f,%8f,%8f,%8f,%8f';
g1='%8f';
xp0=zeros(data_points,1); xp1=xp0;                        % Init
x0=sprintf([g3,'#'],xp0);
Init_flag = U(length(U));                        % Flags
if Init_flag == 0                                % Init RS232
    while s_2.BytesAvailable < 9*data_points & etime(clock,t0) < 5; end
    while ~isempty(x0)                           % Empty buffer
        x1=x0;
        x0=fscanf(s_2);
    end
    xp0=sscanf(x1,'%f,');                        % last value
    Init_flag=1;
else
    while s_2.BytesAvailable < 9*data_points & etime(clock,t0) < 5; end  % Read message
    x0=fscanf(s_2);
    xp0=sscanf(x0,'%f,');
    if s_2.BytesAvailable >0; Init_flag=0;end    % Enforce empty buffer    
end
if length(xp0) ~= data_points 
    xp0 = zeros(data_points,1);     Init_flag=0;
end

Up=sprintf([g6,'#'],[U(1:length(U)-1)]);
ez=0;t1=clock;
while ez == 0                                   % Check for busy TX port
    b=s_2.TransferStatus;  dt = etime(clock,t1);  
    ez = (dt >= 0.2) + (length(b) == 4);        % Idle or Read status
end
if dt < 0.2; fwrite(s_2,Up,'async'); end        % Send control message
dt1=etime(clock,t1);
dt0=etime(clock,t0);
xp = [xp0*Init_flag;Init_flag];

