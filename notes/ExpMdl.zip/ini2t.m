f_ord=1;thru=0;ct=0;npar=f_ord*(1+2)+(2-1)*thru+ct
%SISO, thru=throughput-D, ct=constant output bias
%Filter matrices based on order and bandwidth
f_bw=.1;den=poly(-ones(1,f_ord)*f_bw); [f,q,cc,dd]=tf2ss(10,den);  
W=lyap(f,q*q');[U,S,V]=svd(W);TR=sqrt(inv(S))*U';f=(TR*f*inv(TR))*Tsa;q=TR*q;

QKF=eye(npar,npar)*1e-10;   QKF(1:f_ord,1:f_ord)=eye(f_ord,f_ord)*1e6;
if ct == 1 ; QKF(npar,npar)=1e-8;end

Tsa=.2;N=1;rho=1e9;lambda=.9999;Q=1e-9*eye(2*N,2*N);u_noise=1e-2;y_noise=1e-2;
