function xp=e6_comm(U,s_2);
% Experiment 6 communication function
% Inputs: Control vector, Serial object
% Outputs: Output vector (transmission, init flags)
% KST 10/04

t0=clock;
data_points=4;
g4='%8f,%8f,%8f,%8f';                                % R/W format
g1='%8f';
xp0=zeros(data_points,1); xp1=xp0;                        % Init
x0=sprintf([g4,'#'],xp0);
Init_flag = U(length(U));                        % Flags
if Init_flag == 0                                % Init RS232
    while s_2.BytesAvailable < 9*data_points & etime(clock,t0) < 5; end
    while ~isempty(x0)                           % Empty buffer
        x1=x0;
        x0=fscanf(s_2);
    end
    xp0=sscanf(x1,'%f,');                        % last value
    Init_flag=1;
else
    while s_2.BytesAvailable < 9*data_points & etime(clock,t0) < 5; end  % Read message
    x0=fscanf(s_2);
    xp0=sscanf(x0,'%f,');
    if s_2.BytesAvailable >0; Init_flag=0;end    % Enforce empty buffer    
end
if length(xp0) ~= data_points 
    xp0 = zeros(data_points,1);     Init_flag=0;
end

xp = [xp0;Init_flag];

ZLS=xp(1:2)';N=1;Tsa=.2;
w=logspace(-4,2,300)';GLS=zeros(300,1);
   Pd=tf(ZLS(1:N),[1 -ZLS(N+1:2*N)],Tsa);
   Pc=d2c(Pd); m=bode(Pc,w); GLS(:)=m(:);
   loglog(w,GLS,'r'), hold on
   pause(0.3)
   loglog(w,GLS,'y')
   
   


