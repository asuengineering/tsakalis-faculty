%sample code for serial communication
warning off MATLAB:serial:fscanf:unsuccessfulRead

s_2 = serial('COM2','BaudRate',19200,'FlowControl','software','Timeout',.05);
s_2.InputBufferSize=1024;          
s_2.OutputBufferSize=1024;
s_2.Terminator=35;
s_2
fopen(s_2);
% initialize controller parameters
Tsa=1;
decim=1;
%PID=[.02 100 100/4];

clf
