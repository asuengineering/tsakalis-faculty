S=tf(1,1);
rhoi=logspace(-2,2,10);
for i = 1:length(rhoi)
    rho=rhoi(i);
Q=Ga.c'*Ga.c+rho*(Ga.a'*Ga.c'*Ga.c*Ga.a+norm(Ga.c/100)*eye(size(Ga.a)));
R=1e-5;
K=lqr(Ga.a,Ga.b,Ga.c'*Ga.c+rho*(Ga.a'*Ga.c'*Ga.c*Ga.a+norm(Ga.c/100)*eye(size(Ga.a))),R)
S=[S,ss(Ga.a-Ga.b*K,Ga.b,K,0)];
end
clf
for i = 1:length(rhoi)
hold on
sigma(S(i))
end
