

function bio=exp5abio(flag)
bio = [];
if nargin==0
  bio = [];
                    bio(1).blkName='Pulse Generator';
                    bio(1).sigName='NULL';
                    bio(1).portIdx=0;
                    bio(1).dim=[1,1];
                    bio(1).sigWidth=1;
                    bio(1).sigAddress='&exp5a_B.PulseGenerator';

                    bio(2).blkName='Gain';
                    bio(2).sigName='NULL';
                    bio(2).portIdx=0;
                    bio(2).dim=[1,1];
                    bio(2).sigWidth=1;
                    bio(2).sigAddress='&exp5a_B.Gain';

                    bio(3).blkName='Gain1';
                    bio(3).sigName='NULL';
                    bio(3).portIdx=0;
                    bio(3).dim=[1,1];
                    bio(3).sigWidth=1;
                    bio(3).sigAddress='&exp5a_B.Gain1';

                    bio(4).blkName='Rate Transition';
                    bio(4).sigName='NULL';
                    bio(4).portIdx=0;
                    bio(4).dim=[4,1];
                    bio(4).sigWidth=4;
                    bio(4).sigAddress='&exp5a_B.RateTransition[0]';

                    bio(5).blkName='MM 1';
                    bio(5).sigName='NULL';
                    bio(5).portIdx=0;
                    bio(5).dim=[1,1];
                    bio(5).sigWidth=1;
                    bio(5).sigAddress='&exp5a_B.MM1';

                    bio(6).blkName='Step1';
                    bio(6).sigName='NULL';
                    bio(6).portIdx=0;
                    bio(6).dim=[1,1];
                    bio(6).sigWidth=1;
                    bio(6).sigAddress='&exp5a_B.Step1';

                    bio(7).blkName='Step2';
                    bio(7).sigName='NULL';
                    bio(7).portIdx=0;
                    bio(7).dim=[1,1];
                    bio(7).sigWidth=1;
                    bio(7).sigAddress='&exp5a_B.Step2';

                    bio(8).blkName='Sum1';
                    bio(8).sigName='NULL';
                    bio(8).portIdx=0;
                    bio(8).dim=[1,1];
                    bio(8).sigWidth=1;
                    bio(8).sigAddress='&exp5a_B.Sum1';

                    bio(9).blkName='CONTROL/Unit Delay';
                    bio(9).sigName='NULL';
                    bio(9).portIdx=0;
                    bio(9).dim=[1,1];
                    bio(9).sigWidth=1;
                    bio(9).sigAddress='&exp5a_B.UnitDelay';

                    bio(10).blkName='CONTROL/AW-PID 1/Dis. Transfer Fcn1';
                    bio(10).sigName='NULL';
                    bio(10).portIdx=0;
                    bio(10).dim=[1,1];
                    bio(10).sigWidth=1;
                    bio(10).sigAddress='&exp5a_B.DisTransferFcn1';

                    bio(11).blkName='CONTROL/AW-PID 1/Low-pass filter';
                    bio(11).sigName='NULL';
                    bio(11).portIdx=0;
                    bio(11).dim=[1,1];
                    bio(11).sigWidth=1;
                    bio(11).sigAddress='&exp5a_B.Lowpassfilter';

                    bio(12).blkName='CONTROL/AW-PID 1/Proportional';
                    bio(12).sigName='NULL';
                    bio(12).portIdx=0;
                    bio(12).dim=[1,1];
                    bio(12).sigWidth=1;
                    bio(12).sigAddress='&exp5a_B.Proportional';

                    bio(13).blkName='CONTROL/AW-PID 1/Proportional3';
                    bio(13).sigName='NULL';
                    bio(13).portIdx=0;
                    bio(13).dim=[1,1];
                    bio(13).sigWidth=1;
                    bio(13).sigAddress='&exp5a_B.Proportional3';

                    bio(14).blkName='CONTROL/AW-PID 1/gain';
                    bio(14).sigName='NULL';
                    bio(14).portIdx=0;
                    bio(14).dim=[1,1];
                    bio(14).sigWidth=1;
                    bio(14).sigAddress='&exp5a_B.gain';

                    bio(15).blkName='CONTROL/AW-PID 1/Saturation';
                    bio(15).sigName='NULL';
                    bio(15).portIdx=0;
                    bio(15).dim=[1,1];
                    bio(15).sigWidth=1;
                    bio(15).sigAddress='&exp5a_B.Saturation';

                    bio(16).blkName='CONTROL/AW-PID 1/P+I+D';
                    bio(16).sigName='NULL';
                    bio(16).portIdx=0;
                    bio(16).dim=[1,1];
                    bio(16).sigWidth=1;
                    bio(16).sigAddress='&exp5a_B.PID';

                    bio(17).blkName='CONTROL/AW-PID 1/error';
                    bio(17).sigName='NULL';
                    bio(17).portIdx=0;
                    bio(17).dim=[1,1];
                    bio(17).sigWidth=1;
                    bio(17).sigAddress='&exp5a_B.error';

                    bio(18).blkName='CONTROL/meas>0/Switch';
                    bio(18).sigName='NULL';
                    bio(18).portIdx=0;
                    bio(18).dim=[1,1];
                    bio(18).sigWidth=1;
                    bio(18).sigAddress='&exp5a_B.Switch';

                    bio(19).blkName='CONTROL/meas>0/Unit Delay3';
                    bio(19).sigName='NULL';
                    bio(19).portIdx=0;
                    bio(19).dim=[1,1];
                    bio(19).sigWidth=1;
                    bio(19).sigAddress='&exp5a_B.UnitDelay3';

                    bio(20).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product';
                    bio(20).sigName='NULL';
                    bio(20).portIdx=0;
                    bio(20).dim=[2,1];
                    bio(20).sigWidth=2;
                    bio(20).sigAddress='&exp5a_B.Product[0]';

                    bio(21).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product1';
                    bio(21).sigName='NULL';
                    bio(21).portIdx=0;
                    bio(21).dim=[2,1];
                    bio(21).sigWidth=2;
                    bio(21).sigAddress='&exp5a_B.Product1[0]';

                    bio(22).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product2';
                    bio(22).sigName='NULL';
                    bio(22).portIdx=0;
                    bio(22).dim=[2,2];
                    bio(22).sigWidth=4;
                    bio(22).sigAddress='&exp5a_B.Product2[0]';

                    bio(23).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product3';
                    bio(23).sigName='NULL';
                    bio(23).portIdx=0;
                    bio(23).dim=[2,2];
                    bio(23).sigWidth=4;
                    bio(23).sigAddress='&exp5a_B.Product3[0]';

                    bio(24).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product4';
                    bio(24).sigName='NULL';
                    bio(24).portIdx=0;
                    bio(24).dim=[2,2];
                    bio(24).sigWidth=4;
                    bio(24).sigAddress='&exp5a_B.Product4[0]';

                    bio(25).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product5';
                    bio(25).sigName='NULL';
                    bio(25).portIdx=0;
                    bio(25).dim=[2,1];
                    bio(25).sigWidth=2;
                    bio(25).sigAddress='&exp5a_B.Product5[0]';

                    bio(26).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product6';
                    bio(26).sigName='NULL';
                    bio(26).portIdx=0;
                    bio(26).dim=[1,1];
                    bio(26).sigWidth=1;
                    bio(26).sigAddress='&exp5a_B.Product6';

                    bio(27).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product7';
                    bio(27).sigName='NULL';
                    bio(27).portIdx=0;
                    bio(27).dim=[2,2];
                    bio(27).sigWidth=4;
                    bio(27).sigAddress='&exp5a_B.Product7[0]';

                    bio(28).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Product8';
                    bio(28).sigName='NULL';
                    bio(28).portIdx=0;
                    bio(28).dim=[2,2];
                    bio(28).sigWidth=4;
                    bio(28).sigAddress='&exp5a_B.Product8[0]';

                    bio(29).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Dot Product';
                    bio(29).sigName='NULL';
                    bio(29).portIdx=0;
                    bio(29).dim=[1,1];
                    bio(29).sigWidth=1;
                    bio(29).sigAddress='&exp5a_B.DotProduct';

                    bio(30).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Reshape';
                    bio(30).sigName='NULL';
                    bio(30).portIdx=0;
                    bio(30).dim=[1,2];
                    bio(30).sigWidth=2;
                    bio(30).sigAddress='&exp5a_B.Reshape[0]';

                    bio(31).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Reshape1';
                    bio(31).sigName='NULL';
                    bio(31).portIdx=0;
                    bio(31).dim=[2,1];
                    bio(31).sigWidth=2;
                    bio(31).sigAddress='&exp5a_B.Reshape1[0]';

                    bio(32).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Reshape2';
                    bio(32).sigName='NULL';
                    bio(32).portIdx=0;
                    bio(32).dim=[2,1];
                    bio(32).sigWidth=2;
                    bio(32).sigAddress='&exp5a_B.Reshape2[0]';

                    bio(33).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Reshape3';
                    bio(33).sigName='NULL';
                    bio(33).portIdx=0;
                    bio(33).dim=[2,1];
                    bio(33).sigWidth=2;
                    bio(33).sigAddress='&exp5a_B.Reshape3[0]';

                    bio(34).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Sum1';
                    bio(34).sigName='NULL';
                    bio(34).portIdx=0;
                    bio(34).dim=[1,1];
                    bio(34).sigWidth=1;
                    bio(34).sigAddress='&exp5a_B.Sum1_d';

                    bio(35).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Sum2';
                    bio(35).sigName='NULL';
                    bio(35).portIdx=0;
                    bio(35).dim=[2,1];
                    bio(35).sigWidth=2;
                    bio(35).sigAddress='&exp5a_B.Sum2_f[0]';

                    bio(36).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Sum3';
                    bio(36).sigName='NULL';
                    bio(36).portIdx=0;
                    bio(36).dim=[2,2];
                    bio(36).sigWidth=4;
                    bio(36).sigAddress='&exp5a_B.Sum3[0]';

                    bio(37).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Sum4';
                    bio(37).sigName='NULL';
                    bio(37).portIdx=0;
                    bio(37).dim=[1,1];
                    bio(37).sigWidth=1;
                    bio(37).sigAddress='&exp5a_B.Sum4';

                    bio(38).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Switch';
                    bio(38).sigName='NULL';
                    bio(38).portIdx=0;
                    bio(38).dim=[2,2];
                    bio(38).sigWidth=4;
                    bio(38).sigAddress='&exp5a_B.Switch_h[0]';

                    bio(39).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Switch1';
                    bio(39).sigName='NULL';
                    bio(39).portIdx=0;
                    bio(39).dim=[2,1];
                    bio(39).sigWidth=2;
                    bio(39).sigAddress='&exp5a_B.Switch1[0]';

                    bio(40).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Unit Delay';
                    bio(40).sigName='NULL';
                    bio(40).portIdx=0;
                    bio(40).dim=[2,1];
                    bio(40).sigWidth=2;
                    bio(40).sigAddress='&exp5a_B.UnitDelay_a[0]';

                    bio(41).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Unit Delay1';
                    bio(41).sigName='NULL';
                    bio(41).portIdx=0;
                    bio(41).dim=[2,2];
                    bio(41).sigWidth=4;
                    bio(41).sigAddress='&exp5a_B.UnitDelay1[0]';

                    bio(42).blkName='CONTROL/AW-PID 1/integrator2/delay';
                    bio(42).sigName='NULL';
                    bio(42).portIdx=0;
                    bio(42).dim=[1,1];
                    bio(42).sigWidth=1;
                    bio(42).sigAddress='&exp5a_B.delay';

                    bio(43).blkName='CONTROL/AW-PID 1/integrator2/error1';
                    bio(43).sigName='NULL';
                    bio(43).portIdx=0;
                    bio(43).dim=[1,1];
                    bio(43).sigWidth=1;
                    bio(43).sigAddress='&exp5a_B.error1';

                    bio(44).blkName='CONTROL/AW-PID 1/integrator2/error2';
                    bio(44).sigName='NULL';
                    bio(44).portIdx=0;
                    bio(44).dim=[1,1];
                    bio(44).sigWidth=1;
                    bio(44).sigAddress='&exp5a_B.error2';

                    bio(45).blkName='CONTROL/AW-PID 1/integrator2/error3';
                    bio(45).sigName='NULL';
                    bio(45).portIdx=0;
                    bio(45).dim=[1,1];
                    bio(45).sigWidth=1;
                    bio(45).sigAddress='&exp5a_B.error3';

                    bio(46).blkName='CONTROL/AW-PID 1/integrator2/Switch';
                    bio(46).sigName='NULL';
                    bio(46).portIdx=0;
                    bio(46).dim=[1,1];
                    bio(46).sigWidth=1;
                    bio(46).sigAddress='&exp5a_B.Switch_n';

                    bio(47).blkName='CONTROL/AW-PID 1/integrator2/Switch2';
                    bio(47).sigName='NULL';
                    bio(47).portIdx=0;
                    bio(47).dim=[1,1];
                    bio(47).sigWidth=1;
                    bio(47).sigAddress='&exp5a_B.Switch2';

                    bio(48).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/Embedded MATLAB Function/p1';
                    bio(48).sigName='y';
                    bio(48).portIdx=0;
                    bio(48).dim=[2,1];
                    bio(48).sigWidth=2;
                    bio(48).sigAddress='&exp5a_B.y[0]';

                    bio(49).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Gain';
                    bio(49).sigName='NULL';
                    bio(49).portIdx=0;
                    bio(49).dim=[1,1];
                    bio(49).sigWidth=1;
                    bio(49).sigAddress='&exp5a_B.Gain_b';

                    bio(50).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Gain1';
                    bio(50).sigName='NULL';
                    bio(50).portIdx=0;
                    bio(50).dim=[1,1];
                    bio(50).sigWidth=1;
                    bio(50).sigAddress='&exp5a_B.Gain1_a';

                    bio(51).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Tapped Delay';
                    bio(51).sigName='NULL';
                    bio(51).portIdx=0;
                    bio(51).dim=[1,1];
                    bio(51).sigWidth=1;
                    bio(51).sigAddress='&exp5a_B.TappedDelay';

                    bio(52).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Tapped Delay1';
                    bio(52).sigName='NULL';
                    bio(52).portIdx=0;
                    bio(52).dim=[1,1];
                    bio(52).sigWidth=1;
                    bio(52).sigAddress='&exp5a_B.TappedDelay1';

                    bio(53).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Sum1';
                    bio(53).sigName='NULL';
                    bio(53).portIdx=0;
                    bio(53).dim=[1,1];
                    bio(53).sigWidth=1;
                    bio(53).sigAddress='&exp5a_B.Sum1_p';

                    bio(54).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Sum2';
                    bio(54).sigName='NULL';
                    bio(54).portIdx=0;
                    bio(54).dim=[1,1];
                    bio(54).sigWidth=1;
                    bio(54).sigAddress='&exp5a_B.Sum2';

                    bio(55).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Uniform Random Number';
                    bio(55).sigName='NULL';
                    bio(55).portIdx=0;
                    bio(55).dim=[1,1];
                    bio(55).sigWidth=1;
                    bio(55).sigAddress='&exp5a_B.UniformRandomNumber';

                    bio(56).blkName='ID-498Textbook/LS_FM_Estim Chidambaram/regressor/Uniform Random Number1';
                    bio(56).sigName='NULL';
                    bio(56).portIdx=0;
                    bio(56).dim=[1,1];
                    bio(56).sigWidth=1;
                    bio(56).sigAddress='&exp5a_B.UniformRandomNumber1';





else
   bio= 94;
end
