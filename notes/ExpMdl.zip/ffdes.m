% transfer function data
P=tf([-.5 1],[.5 1])*tf(1,[40 2]);Q=tf(2,[40 2]);C=tf([3.43 0.61],[1 0]);
W=tf([.5 1],[1 1e-4]);r=1e-3
% compute sensitivities 
S=feedback(1,P*C); SP=feedback(P,C); SQ=Q*S;
G=[W*SP;r]; WT=([W*SQ;0]);
% inner-outer factorization
[SPi,SPip,SPo]=iofr(ss(G)); Stil=inv([SPi,SPip]); 
R=minreal(Stil*WT);
% solve minimization problem
X2=stabproj(R-R.d)+R.d;
H2o=minreal(inv(SPo)*[1 0]*X2);
cut=length(find(abs(eig(H2o))<1e-1));
[H2s,H2f]=slowfast(H2o-H2o.d,cut);H2f=H2f+H2o.d;
[a,b,c,d]=h_sysred(H2f,[],[]); H2=ss(a,b,c,d);

gmax=norm(WT,inf);
gmin=norm(R(2),inf);
while gmax-gmin>0.001
    gam=(gmax+gmin)/2
    r0=(sfl(minreal(R(2))/gam))*gam;
    r1=minreal(R(1)*inv(r0));qm=nehari(r1);
    qm=mnehari(r1);
    q=minreal(inv(SPo)*qm*r0);
    gtest=norm((r(1)-qm)*inv(r0),inf);
    if gtest < 1; gmax=gam; else gmin=gam;end
end
cut=length(find(abs(eig(q))<1e-1));
[qs,qf]=slowfast(q-q.d,cut);qf=qf+q.d;
[a,b,c,d]=h_sysred(qf,[],[]); Hi=ss(a,b,c,d);

% plot results
sigma(Hi,H2); pause
sigma(G*H2-WT,SP*H2-SQ,G*Hi-WT,SP*Hi-SQ)
din=tf(6.456*[1 -.6913],[1 -1],10);
