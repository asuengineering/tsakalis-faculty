% ---- m-file h_preh: for the set-up of controller simulation

TSAMPLE=input('give sampling time [.5/60]  ');
if length(TSAMPLE)<1;TSAMPLE=.5/60;end

%  Higher observer penalty may be required if problems occur with
%    "cold-starts" (i.e., high errors to the controller)

rho1=input('antiwindup observer penalty [10]  ');
if length(rho1)<1;rho1=100;end
gainc=[0,0];

s2u_con=input('Give  Controller file [con1]   ','s');
if length(s2u_con)<1;s2u_con='con1';end

polesf=input('prefilter zeros [10]  ');
if length(polesf)<1;polesf=10;end
zerosf=input('prefilter poles [10]   ');
if length(zerosf)<1;zerosf=10;end

del=.001;gainb=1;weiw=1;weip=1;ashift=1.001;

%--------------------------------------------------------------
% controller discretization

  eval(['load ' s2u_con])
%--------------------------------------------------------------
% feedback filter
if polesf ~= zerosf
 [Afl,Bfl,Cfl,Dfl]=hinf_wgt(length(Dcr),zerosf,polesf,1);
 [Act,Bct,Cct,Dct]=hinf_wgt(length(Dcr),polesf,zerosf,1);
 [Acr,Bcr,Ccr,Dcr]=series(Act,Bct,Cct,Dct,Acr,Bcr,Ccr,Dcr);
 [Aci,Bci,Cci,Dci]=bilin(Acr,Bcr,Ccr,Dcr,1,'BwdRec',TSAMPLE);
 [Afo,Bfo,Cfo,Dfo]=bilin(Afl,Bfl,Cfl,Dfl,1,'BwdRec',TSAMPLE);
else
 [Aci,Bci,Cci,Dci]=bilin(Acr,Bcr,Ccr,Dcr,1,'BwdRec',TSAMPLE);
 [Afl,Bfl,Cfl,Dfl]=hinf_wgt(length(Dcr),zerosf,polesf,1);
 [Afo,Bfo,Cfo,Dfo]=bilin(Afl,Bfl,Cfl,Dfl,1,'BwdRec',TSAMPLE);
end

%--------------------------------------------------------------
%  Compute the stabilizing observer gains

disp('solve Riccatis')

[ncii,naii]=size(Cci);
IMS=diag(eye(ncii));
LDi=dlqr(ashift*Aci',Cci',(del*eye(naii,naii)+Bci*Bci'*gainb),...
         (diag(rho1)*diag(IMS)+Cci*Cci'*gainc(1)))';




