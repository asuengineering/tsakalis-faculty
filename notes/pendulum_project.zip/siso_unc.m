function [frun,Tb,Sb]=siso_unc(g_m,t,u,y,bw);

u=u-mean(u); y=y-mean(y);
[num,den]=tfdata(g_m,'v');
n=length(den)-1; no_pts=length(u); step_siz=t(2)-t(1);
nbin=50;

df=poly(-ones(n,1)*bw);
N=tf(num,df); D1=tf(df-den,df);
v1=lsim(N,u,t);
v2=lsim(D1,y,t);
err=y-v1-v2;

fr =([1:no_pts]'-1)*2*pi/no_pts/step_siz;fr(1)=fr(2)/20;
fe=abs(fft(err)).^2; fu=abs(fft(u)).^2; fy=abs(fft(y)).^2;

frun=logspace(log10(fr(2)),log10(pi/step_siz),nbin+1)';
FE=zeros(nbin,1); FU=FE; FY=FE; 

fr1=0;
for i = 1:nbin
    ind = find(fr<sqrt(frun(i)*frun(i+1)) & fr>=fr1);
    fr1=sqrt(frun(i)*frun(i+1));
    FE(i)=sqrt(sum(fe(ind)));
    FU(i)=sqrt(sum(fu(ind)));
    FY(i)=sqrt(sum(fy(ind)));
end
frun=frun(1:nbin);

mag_d=bode(df,den,frun);
mag_p=bode(num,den,frun);

Sb = (FE./(1e-6+FY)).*mag_d; Sb=1./(1e-6+Sb);
Tb = (FE./(1e-6+FU)).*mag_d./mag_p;  Tb=1./(1e-6+Tb);
Sb=min(Sb,100); Tb=min(Tb,100);

ind_bw =max(find(frun<bw));
Tb(1:ind_bw)=100+0*Tb(1:ind_bw);
Sb(ind_bw+1:nbin)=100+0*Sb(ind_bw+1:nbin);


    
    